﻿using System;

namespace game_test_1
{
    internal class Program
    {
        static void Main()
        {
            //console aesthetics
            Console.BackgroundColor = ConsoleColor.Cyan;
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.White;

            //name variable
            string CharacterName;

            //title
            Console.Title = "The System";

            //introductory text
            Console.WriteLine("Loading package: Alternate Universe...");
            Console.ReadKey();

            Console.WriteLine("Loading package: Fix-it Fic...");
            Console.ReadKey();

            Console.WriteLine("Loading package: User 002...");
            Console.WriteLine("Loading Failed. Rebooting...");
            Console.WriteLine();
            Console.ReadKey();

            Console.WriteLine("Loading package: User 002...");
            Console.WriteLine("Loading Failed. Abandoning Processes. Beginning emergency protocol.");
            Console.WriteLine();
            Console.ReadKey();

            Console.WriteLine("Dear user, we sincerely apologize for the failure of the System.");
            Console.WriteLine("In accordance with standard procedure, you are being offered the special VIP 'DIY' package.");
            Console.WriteLine();
            Console.WriteLine("Please enter your name below.");

            //getting the character's name and responding
            CharacterName = Console.ReadLine();
            Console.WriteLine();
            Console.WriteLine("...");
            Console.ReadKey();
            Console.WriteLine("......");
            Console.ReadKey();
            Console.WriteLine("..........");
            Console.ReadKey();

            Console.WriteLine("The System would have hoped you would pick a more serious name, but supposes " + CharacterName + " is suitable.");
            Console.WriteLine();
            Console.WriteLine("Dear user, please enjoy the scnario: 'Wait, I thought 'Marital' was a typo!!'");
            Console.ReadKey();

            


        }
    }
}
